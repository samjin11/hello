const express = require('express');
const app = express();
const path = require('path');
const Data = require('./models/DataSchema');
const mongoose = require('mongoose')

mongoose.connect('mongodb+srv://rohangupta:123@cluster0.6njkk.mongodb.net/myFirstDatabase?retryWrites=true&w=majority', { useNewUrlParser: true })
    .then(() => console.log('MongoDB Connected'))
    .catch(() => console.log('MongoDB Error'))

app.use(express.static(path.join(__dirname, '/styles')));
app.use(express.static(path.join(__dirname, '/images')));
app.use(express.urlencoded({ extended: true }));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '/views'));


app.get('/', async (req, res) => {
    console.log('home')
    const data = await Data.find({});
    res.render('home', { data });
})

app.get('/add-edit', (req, res) => {
    res.render('add-edit');
})

app.get('/delete-retrieve', async (req, res) => {
    const data = await Data.find({});
    res.render('delete-reterive1', { data });
})

app.get('/delete/:id', async (req, res) => {
    const { id } = req.params;
    console.log(id);
    await Data.findByIdAndDelete(id);
    res.redirect('/delete-retrieve')
})

app.get('/new-employee', (req, res) => {
    res.render('new-employee1')
})

app.post('/saveForm', async (req, res) => {
    const dataSaved = new Data(req.body);
    await dataSaved.save();
    res.redirect('/');
})

app.get('*', (req, res) => {
    res.send('lol')
})

app.listen(4000, () => console.log('Listening on 4000'))