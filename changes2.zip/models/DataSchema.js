const mongoose = require('mongoose');
const { Schema } = mongoose;

const dataSchema = new Schema({
    ICNO: String,
    first_name: String,
    second_name: String,
    last_name: String,
    DOB: String,
    Date_of_joining_sspl: String,
    Date_of_joining_drdo: String,
    Date_of_present: String,
    Internal_no: String,
    mobile_no: String,
    perma_address: String,
    place_of_posting: String,
    Presenr_address: String,
    Internal_mail: String,
    sspl_mail: String,
    Image: String,
    perma_address_01: String,
    select1: String,
    select2: String,
    select3: String,
    select4: String,
    select5: String,
    select6: String,
    select7: String
});

const Data = mongoose.model('Data', dataSchema);
module.exports = Data;
